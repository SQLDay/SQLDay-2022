DECLARE @Counter INT
DECLARE @rand INT
SET @Counter=1

WHILE ( @Counter <= 1500)
BEGIN
    SET @rand = RAND()*100

	INSERT INTO [ContosoRetailDW].[dbo].[FactOrders]
	SELECT TOP (@rand)
		   CONVERT(DATE, GETDATE()) AS [DateKey]
		  ,[StoreKey]
		  ,[ProductKey]
		  ,[PromotionKey]
		  ,[CurrencyKey]
		  ,[CustomerKey]
		  ,[SalesQuantity]
		  ,[SalesAmount]
	  FROM [ContosoRetailDW].[dbo].[FactOrders] (NOLOCK)
	  WHERE DateKey = DATEADD(DAY,@rand, '2021-01-01')

    SET @Counter  = @Counter  + 1
	WAITFOR DELAY '00:00:02'
END