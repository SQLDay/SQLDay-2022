SELECT COUNT(1)
  FROM [ContosoRetailDW].[dbo].[FactOrders] (NOLOCK)
  --14 221 828

SELECT COUNT(1)
  FROM [ContosoRetailDW].[dbo].[FactOrders] (NOLOCK)
  WHERE DateKey BETWEEN '2022-01-01' AND DATEADD ( DAY, -1, CAST ( GETDATE() AS DATE ) )
  -- 1 594 220

SELECT COUNT(1)
  FROM [ContosoRetailDW].[dbo].[FactOrders] (NOLOCK)
  WHERE DateKey >= CAST ( GETDATE() AS DATE )
  -- 0