DROP TABLE IF EXISTS [ContosoRetailDW].[dbo].[FactOrders] 

SELECT
	DATEADD (YEAR, 12, [DateKey]) AS [DateKey], 
	[StoreKey], 
	[ProductKey], 
	[PromotionKey], 
	[CurrencyKey], 
	[CustomerKey], 
	[SalesQuantity], 
	[SalesAmount]
  INTO [ContosoRetailDW].[dbo].[FactOrders]
  FROM [ContosoRetailDW].[dbo].[FactOnlineSales]

INSERT INTO [ContosoRetailDW].[dbo].[FactOrders]
SELECT
	DATEADD (YEAR, 13, [DateKey]) AS [DateKey], 
	[StoreKey], 
	[ProductKey], 
	[PromotionKey], 
	[CurrencyKey], 
	[CustomerKey], 
	[SalesQuantity], 
	[SalesAmount]
  FROM [ContosoRetailDW].[dbo].[FactOnlineSales]
  WHERE DATEADD (YEAR, 13, [DateKey]) BETWEEN '2022-01-01' AND DATEADD(DAY,-1,GETDATE())