/*************************************/
/* Regular expressions in SQL Server */
/*************************************/

-- Infrastructure
USE master
GO
DROP DATABASE IF EXISTS RegExSQLServer;
GO
CREATE DATABASE RegExSQLServer;
GO
EXEC sys.sp_configure  'external scripts enabled', 1;
RECONFIGURE WITH OVERRIDE;
GO
USE RegExSQLServer
GO


-- Test data
/*
Java examples based on MS
Tutorial: Search for a string using regular expressions (regex) in Java
(https://docs.microsoft.com/en-us/sql/language-extensions/tutorials/search-for-string-using-regular-expressions-in-java?view=sql-server-ver15)
*/

DROP TABLE IF EXISTS dbo.javatest;
GO
CREATE TABLE dbo.javatest 
(
 id INT NOT NULL PRIMARY KEY,
 txt1 NVARCHAR(30) NOT NULL
)
GO
INSERT INTO dbo.javatest(id, txt1) VALUES (1, N'This sentence contains java')
INSERT INTO dbo.javatest(id, txt1) VALUES (2, N'This sentence does not')
INSERT INTO dbo.javatest(id, txt1) VALUES (3, N'I love Java!')
GO

-- Some more serious test data
DROP TABLE IF EXISTS dbo.RegExTest;
CREATE TABLE dbo.RegExTest 
(
 id INT NOT NULL,
 txt1 NVARCHAR(46) NOT NULL,
 xml1 XML NOT NULL,
 CONSTRAINT PK_RegExTest_id PRIMARY KEY CLUSTERED (id)
)
GO

-- Demo data - ~30s
TRUNCATE TABLE dbo.RegExTest;
SET NOCOUNT ON;
DECLARE @i AS INT = 0,
 @guid AS NVARCHAR(36),
 @pos AS INT = 0,
 @txt1 AS NVARCHAR(46),
 @xml1 AS XML;
WHILE @i < 100000
BEGIN
 SET @i += 1;
 SET @guid = CAST(NEWID() AS NVARCHAR(36));
 SET @pos = ROUND(36 * RAND(), 0);
 IF @i % 5 = 0
  BEGIN
   SET @txt1 = LEFT(@guid, @pos) + N' ! Java ! ' + RIGHT(@guid, 36 - @pos);
  END
 ELSE
  BEGIN
   SET @txt1 = LEFT(@guid, @pos) + N' ! XXXX ! ' + RIGHT(@guid, 36 - @pos);
  END
 SET @xml1 = N'<row x="' + @txt1 + N'" />'
 INSERT INTO dbo.RegExTest(id, txt1, xml1)
 VALUES (@i, @txt1, @xml1);
END;
GO
-- Check the data, warm the cache
SELECT *
FROM dbo.RegExTest;
GO

-- Table for the results
DROP TABLE IF EXISTS dbo.RegExTestResults;
CREATE TABLE dbo.RegExTestResults 
(
 id INT NOT NULL IDENTITY(1,1),
 languageExpression NVARCHAR(50) NOT NULL,
 indexType NVARCHAR(50) NOT NULL,
 cYear INT NOT NULL,
 linesOfCode INT NOT NULL,
 timeMs INT NOT NULL,
 CONSTRAINT PK_RegExTestResults_id PRIMARY KEY CLUSTERED (id)
)
GO

/* A nice backup
SELECT *
INTO dbo.RegExTestResultsBak
FROM dbo.RegExTestResults;
GO
*/
/* Truncate the results
TRUNCATE TABLE dbo.RegExTestResults;
GO
*/

-- Set up Java
/* Drop if needed 
DROP EXTERNAL LIBRARY javasdk;
DROP EXTERNAL LIBRARY sqlregex;
DROP EXTERNAL LANGUAGE Java;
GO
*/
CREATE EXTERNAL LANGUAGE Java
FROM
(CONTENT = N'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\Binn\java-lang-extension.zip',
 FILE_NAME = 'javaextension.dll')
GO
CREATE EXTERNAL LIBRARY javasdk
FROM (CONTENT = 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\Binn\mssql-java-lang-extension.jar')
WITH (LANGUAGE = 'Java');
GO
CREATE EXTERNAL LIBRARY sqlregex
FROM (CONTENT = 'C:\RegExSQLServer\sqlregex.jar')
WITH (LANGUAGE = 'Java');
GO
-- 13 lines


/* Java code
package pkg;

import com.microsoft.sqlserver.javalangextension.PrimitiveDataset;
import com.microsoft.sqlserver.javalangextension.AbstractSqlServerExtensionExecutor;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.regex.*;

public class RegexSample extends AbstractSqlServerExtensionExecutor {
    private Pattern expr;

    public RegexSample() {
        // Setup the expected extension version, and class to use for input and output dataset
        executorExtensionVersion = SQLSERVER_JAVA_LANG_EXTENSION_V1;
        executorInputDatasetClassName = PrimitiveDataset.class.getName();
        executorOutputDatasetClassName = PrimitiveDataset.class.getName();
    }
    
    public PrimitiveDataset execute(PrimitiveDataset input, LinkedHashMap<String, Object> params) {
        // Validate the input parameters and input column schema
        validateInput(input, params);

        int[] inIds = input.getIntColumn(0);
        String[] inValues = input.getStringColumn(1);
        int rowCount = inValues.length;

        String regexExpr = (String)params.get("regexExpr");
        expr = Pattern.compile(regexExpr);

        System.out.println("regex expression: " + regexExpr);

        // Lists to store the output data
        LinkedList<Integer> outIds = new LinkedList<Integer>();
        LinkedList<String> outValues = new LinkedList<String>();

        // Evaluate each row
        for(int i = 0; i < rowCount; i++) {
            if (check(inValues[i])) {
                outIds.add(inIds[i]);
                outValues.add(inValues[i]);
            }
        }

        int outputRowCount = outValues.size();

        int[] idOutputCol = new int[outputRowCount];
        String[] valueOutputCol = new String[outputRowCount];

        // Convert the list of output columns to arrays
        outValues.toArray(valueOutputCol);

        ListIterator<Integer> it = outIds.listIterator(0);
        int rowId = 0;

        System.out.println("Output data:");
        while (it.hasNext()) {
            idOutputCol[rowId] = it.next().intValue();

            System.out.println("ID: " + idOutputCol[rowId] + " Value: " + valueOutputCol[rowId]);
            rowId++;
        }

        // Construct the output dataset
        PrimitiveDataset output = new PrimitiveDataset();

        output.addColumnMetadata(0, "ID", java.sql.Types.INTEGER, 0, 0);
        output.addColumnMetadata(1, "Text", java.sql.Types.NVARCHAR, 0, 0);

        output.addIntColumn(0, idOutputCol, null);
        output.addStringColumn(1, valueOutputCol);

        return output;
    }

    private void validateInput(PrimitiveDataset input, LinkedHashMap<String, Object> params) {
        // Check for the regex expression input parameter
        if (params.get("regexExpr") == null) {
            throw new IllegalArgumentException("Input parameter 'regexExpr' is not found");
        }

        // The expected input schema should be at least 2 columns, (INTEGER, STRING)
        if (input.getColumnCount() < 2) {
            throw new IllegalArgumentException("Unexpected input schema, schema should be an (INTEGER, NVARCHAR or VARCHAR)");
        }

        // Check that the input column types are expected
        if (input.getColumnType(0) != java.sql.Types.INTEGER &&
                (input.getColumnType(1) != java.sql.Types.VARCHAR && input.getColumnType(1) == java.sql.Types.NVARCHAR )) {
            throw new IllegalArgumentException("Unexpected input schema, schema should be an (INTEGER, NVARCHAR or VARCHAR)");
        }
    }

    private boolean check(String text) {
        Matcher m = expr.matcher(text);

        return m.find();
    }
}
*/
-- 99 lines

-- Test Java
CREATE OR ALTER PROCEDURE dbo.java_regex @expr nvarchar(200), @query nvarchar(400)
AS
BEGIN
--Call the Java program by giving the package.className in @script
--The method invoked in the Java code is always the "execute" method
EXEC sp_execute_external_script
  @language = N'Java'
, @script = N'pkg.RegexSample'
, @input_data_1 = @query
, @params = N'@regexExpr nvarchar(200)'
, @regexExpr = @expr
WITH RESULT SETS ((ID int, text nvarchar(100)));
END;
GO
-- 13 lines

-- Test Java procedure on small dataset
EXECUTE [dbo].[java_regex] N'[Jj]ava', N'SELECT id, txt1 FROM dbo.javatest';
GO
-- 1 line

-- Test Java procedure on the large dataset
DECLARE @s AS DATETIME = SYSDATETIME();
EXECUTE [dbo].[java_regex] N'[Jj]ava', N'SELECT id, txt1 FROM dbo.RegExTest';
DECLARE @e AS DATETIME = SYSDATETIME();
SELECT @s, @e, DATEDIFF(ms, @s, @e);
INSERT INTO dbo.RegExTestResults
(languageExpression, indexType, cYear, linesOfCode, timeMs)
VALUES
(N'Java', 'CL scan', 2019, 126, DATEDIFF(ms, @s, @e));
GO
-- 1 line
TRUNCATE TABLE dbo.RegExTestResults;


-- CS function
/*
Of course, there are also .NET (CS and VB) RegEx examples in SQL Server documentation
https://docs.microsoft.com/en-us/previous-versions/sql/sql-server-2016/ff878119%28v%3dsql.130%29
*/

/* CS code (assembly must be signed)
using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;
using System.Text;
using System.Text.RegularExpressions;

public partial class ClrUtilities
{

    // RegexIsMatch function
    // Validates input string against regular expression
    [SqlFunction(IsDeterministic = true, DataAccess = DataAccessKind.None)]
    public static SqlBoolean RegexIsMatch(SqlString input,
    SqlString pattern)
    {
        if (input.IsNull || pattern.IsNull)
            return SqlBoolean.Null;
        else
            return (SqlBoolean)Regex.IsMatch(input.Value, pattern.Value,
              RegexOptions.CultureInvariant);
    }

}
*/
-- 25 lines

-- Enable CLR and create the login for the key and grant the unsafe assembly permission
-- Note: the CS code muxt be signed
USE master;
EXEC sys.sp_configure 'clr enabled', 1;
RECONFIGURE;
GO
USE master
GO
IF EXISTS ( SELECT * FROM sys.server_principals WHERE name = N'Trusted_Assembly_Login' )
	DROP LOGIN Trusted_Assembly_Login
IF EXISTS ( SELECT * FROM sys.asymmetric_keys WHERE name = N'RegExCSKey')
	DROP ASYMMETRIC KEY RegExCSKey;
GO
CREATE ASYMMETRIC KEY RegExCSKey
FROM EXECUTABLE FILE = 'C:\RegExSQLServer\RegExCS\RegExCS\bin\Debug\RegExCS.dll';
GO
CREATE LOGIN Trusted_Assembly_Login FROM ASYMMETRIC KEY RegExCSKey;
GO
GRANT UNSAFE ASSEMBLY TO Trusted_Assembly_Login;
GO
-- 7 lines


-- Create assembly 
USE RegExSQLServer;
GO
CREATE ASSEMBLY CLRUtilities
FROM 'C:\RegExSQLServer\RegExCS\RegExCS\bin\Debug\RegExCS.dll'
WITH PERMISSION_SET = SAFE;
GO
-- Create RegexIsMatch function
IF OBJECT_ID('dbo.RegexIsMatch', 'FS') IS NOT NULL
  DROP FUNCTION dbo.RegexIsMatch;
GO
CREATE FUNCTION dbo.RegexIsMatch
  (@input AS NVARCHAR(MAX), @pattern AS NVARCHAR(MAX)) 
RETURNS BIT
WITH RETURNS NULL ON NULL INPUT 
EXTERNAL NAME CLRUtilities.ClrUtilities.RegexIsMatch;
GO
-- 14 lines

-- check e-mail address - RegEx = N'^([\w-]+\.)*?[\w-]+@[\w-]+\.([\w-]+\.)*?[\w]+$'
SELECT dbo.RegexIsMatch(
  N'dejan@solidq.com',
  N'^([\w-]+\.)*?[\w-]+@[\w-]+\.([\w-]+\.)*?[\w]+$');
SELECT dbo.RegexIsMatch(
  N'dejan#solidq.com',
  N'^([\w-]+\.)*?[\w-]+@[\w-]+\.([\w-]+\.)*?[\w]+$');
GO

-- Test CS procedure on the large dataset
DECLARE @s AS DATETIME = SYSDATETIME();
SELECT id, txt1
FROM dbo.RegExTest
WHERE dbo.RegexIsMatch(txt1, N'[Jj]ava') = 1;
DECLARE @e AS DATETIME = SYSDATETIME();
SELECT @s, @e, DATEDIFF(ms, @s, @e);
INSERT INTO dbo.RegExTestResults
(languageExpression, indexType, cYear, linesOfCode, timeMs)
VALUES
(N'CS', 'CL scan', 2005, 49, DATEDIFF(ms, @s, @e));
GO
-- 3 lines

-- Simple LIKE operator
DECLARE @s AS DATETIME = SYSDATETIME();
SELECT id, txt1
FROM dbo.RegExTest
WHERE txt1 LIKE '%Java%';
DECLARE @e AS DATETIME = SYSDATETIME();
SELECT @s, @e, DATEDIFF(ms, @s, @e);
INSERT INTO dbo.RegExTestResults
(languageExpression, indexType, cYear, linesOfCode, timeMs)
VALUES
(N'TSQL LIKE', 'CL scan', 2000, 3, DATEDIFF(ms, @s, @e));
GO

-- Try with a NCL index
CREATE NONCLUSTERED INDEX IX_RegExTest_txt1  
 ON dbo.RegExTest (txt1);  
GO
-- Check the data, warm the cache
SELECT id, txt1
FROM dbo.RegExTest;
GO
-- LIKE with a covering NCL
DECLARE @s AS DATETIME = SYSDATETIME();
SELECT id, txt1
FROM dbo.RegExTest
WHERE txt1 LIKE '%Java%';
DECLARE @e AS DATETIME = SYSDATETIME();
SELECT @s, @e, DATEDIFF(ms, @s, @e);
INSERT INTO dbo.RegExTestResults
(languageExpression, indexType, cYear, linesOfCode, timeMs)
VALUES
(N'TSQL LIKE', 'NCL covering scan', 2000, 3, DATEDIFF(ms, @s, @e));
GO

-- XQuery contains
-- XQuery matches not supported in SQL Server
DECLARE @s AS DATETIME = SYSDATETIME();
SELECT id, txt1
FROM dbo.RegExTest
WHERE xml1.exist('(/row/@x)[contains(., "Java")]') = 1 ;
DECLARE @e AS DATETIME = SYSDATETIME();
SELECT @s, @e, DATEDIFF(ms, @s, @e);
INSERT INTO dbo.RegExTestResults
(languageExpression, indexType, cYear, linesOfCode, timeMs)
VALUES
(N'XQuery', 'CL scan', 2005, 3, DATEDIFF(ms, @s, @e))
GO

-- Try with XML indexes
CREATE PRIMARY XML INDEX PXML_RegExTest_xml1  
 ON dbo.RegExTest (xml1);  
GO
CREATE XML INDEX IXML_RegExTest_xml1_Path   
 ON dbo.RegExTest (xml1)
 USING XML INDEX PXML_RegExTest_xml1 FOR VALUE;  
GO
DECLARE @s AS DATETIME = SYSDATETIME();
SELECT id, txt1
FROM dbo.RegExTest
WHERE xml1.exist('(/row/@x)[contains(., "Java")]') = 1 ;
DECLARE @e AS DATETIME = SYSDATETIME();
SELECT @s, @e, DATEDIFF(ms, @s, @e);
INSERT INTO dbo.RegExTestResults
(languageExpression, indexType, cYear, linesOfCode, timeMs)
VALUES
(N'XQuery', 'XML Primary', 2005, 3, DATEDIFF(ms, @s, @e))
GO

-- Full-Text search
-- Check whether Full-Text and Semantic search is installed
SELECT SERVERPROPERTY('IsFullTextInstalled');
GO
-- Install FTS is it is not installed yet
-- Full-text catalog
CREATE FULLTEXT CATALOG RegExFtCatalog;
GO
-- Full-text index
CREATE FULLTEXT INDEX ON dbo.RegExTest
( 
  txt1 Language 1033
)
KEY INDEX PK_RegExTest_id
ON RegExFtCatalog
WITH CHANGE_TRACKING AUTO;
GO

-- Test FTS
DECLARE @s AS DATETIME = SYSDATETIME();
SELECT id, txt1
FROM dbo.RegExTest
WHERE CONTAINS(txt1, N'Java');
DECLARE @e AS DATETIME = SYSDATETIME();
SELECT @s, @e, DATEDIFF(ms, @s, @e);
INSERT INTO dbo.RegExTestResults
(languageExpression, indexType, cYear, linesOfCode, timeMs)
VALUES
(N'TSQL FTS CONTAINS', 'FTS table function', 2000, 3, DATEDIFF(ms, @s, @e))
GO

-- Using R
DECLARE @s AS DATETIME = SYSDATETIME();
EXECUTE sys.sp_execute_external_script
 @language=N'R',
 @script = 
  N'
    library(RevoScaleR)
	RT$javamatch <- NA
	myXformFunc <- function(dataList) {
      dataList$javamatch <- grepl("[Jj]ava", dataList$txt1)
     return (dataList)
    }
    RT1 <- rxDataStep(inData = RT, 
                      transformFunc = myXformFunc,
                      rowSelection = javamatch == TRUE)
   '
 ,@input_data_1 = N'
    SELECT id, txt1
    FROM dbo.RegExTest;'
 ,@input_data_1_name =  N'RT'
 ,@output_data_1_name = N'RT1'
WITH RESULT SETS 
(
 ("id"        INT          NOT NULL,
  "txt1"      NVARCHAR(46) NOT NULL,
  "javamatch" BIT          NOT NULL)
);
DECLARE @e AS DATETIME = SYSDATETIME();
SELECT @s, @e, DATEDIFF(ms, @s, @e);
INSERT INTO dbo.RegExTestResults
(languageExpression, indexType, cYear, linesOfCode, timeMs)
VALUES
(N'R rxDataStep()', 'NCL covering scan', 2016, 25, DATEDIFF(ms, @s, @e))
GO

-- Using Python
DECLARE @s AS DATETIME = SYSDATETIME();
EXECUTE sys.sp_execute_external_script 
@language =N'Python',
@script=N'
import numpy as np
import pandas as pd
RT1 = RT[RT.txt1.str.contains("Java", regex= True, na=False)]
' 
,@input_data_1 = N'
    SELECT id, txt1
    FROM dbo.RegExTest;'
,@output_data_1_name = N'RT1'
,@input_data_1_name =  N'RT'
WITH RESULT SETS 
(
 ("id"        INT          NOT NULL,
  "txt1"      NVARCHAR(46) NOT NULL)
);
DECLARE @e AS DATETIME = SYSDATETIME();
SELECT @s, @e, DATEDIFF(ms, @s, @e);
INSERT INTO dbo.RegExTestResults
(languageExpression, indexType, cYear, linesOfCode, timeMs)
VALUES
(N'Python', 'NCL covering scan', 2017, 17, DATEDIFF(ms, @s, @e))
GO

-- R with data.table
-- Create external library
CREATE EXTERNAL LIBRARY [data.table]
FROM (CONTENT = 'C:\RegExSQLServer\data.table_1.12.0.zip') 
WITH (LANGUAGE = 'R');
GO
-- Calling R
DECLARE @s AS DATETIME = SYSDATETIME();
EXECUTE sys.sp_execute_external_script
 @language=N'R',
 @script = 
  N'
    library(data.table)
    RTD <- data.table(RT)
	RTDJ <- RTD[grepl("[Jj]ava", txt1)]
   '
 ,@input_data_1 = N'
    SELECT id, txt1
    FROM dbo.RegExTest;'
 ,@input_data_1_name =  N'RT'
 ,@output_data_1_name = N'RTDJ'
WITH RESULT SETS 
(
 ("id"        INT          NOT NULL,
  "txt1"      NVARCHAR(46) NOT NULL)
);
DECLARE @e AS DATETIME = SYSDATETIME();
SELECT @s, @e, DATEDIFF(ms, @s, @e);
INSERT INTO dbo.RegExTestResults
(languageExpression, indexType, cYear, linesOfCode, timeMs)
VALUES
(N'R data table', 'NCL covering scan', 2016, 20, DATEDIFF(ms, @s, @e))
GO


-- Check the results
SELECT id, languageExpression, indexType,
 cYear, linesOfCode, timeMs
FROM dbo.RegExTestResults
ORDER BY cYear;
SELECT id, languageExpression, indexType,
 cYear, linesOfCode, timeMs
FROM dbo.RegExTestResults
ORDER BY linesOfCode;
SELECT id, languageExpression, indexType,
 cYear, linesOfCode, timeMs
FROM dbo.RegExTestResults
ORDER BY timeMs;
SELECT id, languageExpression, indexType,
 cYear, linesOfCode, timeMs
FROM dbo.RegExTestResults
ORDER BY cYear, timeMs;

-- Make a copy of the results
USE AdventureWorksDW2017;
GO
DROP TABLE IF EXISTS dbo.RegExTestResults;
SELECT *
INTO dbo.RegExTestResults
FROM RegExSQLServer.dbo.RegExTestResults;
GO
