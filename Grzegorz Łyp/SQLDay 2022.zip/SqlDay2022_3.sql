-- we�my sobie dodatkowo licznik
create or alter function dbo.GetPersonIdRefTable_Inline(@PersonID int)
returns table
as
return(
	SELECT COALESCE(r1.TableName, r2.TableName, r3.TableName, r4.TableName) TableName,
			COALESCE(r1.Number, r2.Number, r3.Number, r4.Number) Number
	FROM (select 1 a) x
	OUTER APPLY (Select  N'Sales.Invoices' TableName, count(1) Number from Sales.Invoices s 
					where @PersonID = s.AccountsPersonID) r1
	OUTER APPLY (Select N'Sales.Orders' TableName, count(1) Number from Sales.Orders s 
					where @PersonID = s.ContactPersonID AND r1.TableName is null) r2
	OUTER APPLY (Select N'Sales.Customers' TableName, count(1) Number from Sales.Customers s 
					where @PersonID = s.PrimaryContactPersonID AND r1.TableName is null AND r2.TableName is null) r3
	OUTER APPLY (Select N'Purchasing.Suppliers' TableName, count(1) Number from Purchasing.Suppliers s 
					where @PersonID = s.PrimaryContactPersonID AND r1.TableName is null AND r2.TableName is null AND r3.TableName is null) r4
)
GO

-- grupowanie i licznik
declare @PersonId int = 3032
select * FROM dbo.GetPersonIdRefTable_Inline(@PersonId);
GO

-- ??? - o co chodzi z planem?
declare @PersonId int = 3032
select TableName FROM dbo.GetPersonIdRefTable_Inline(@PersonId);
GO

-- poprawka
create or alter function dbo.GetPersonIdRefTable_Inline(@PersonID int)
returns table
as
return(
	SELECT COALESCE(r1.TableName, r2.TableName, r3.TableName, r4.TableName) TableName,
			COALESCE(r1.Number, r2.Number, r3.Number, r4.Number) Number
	FROM (select 1 a) x
	OUTER APPLY (Select  N'Sales.Invoices' TableName, count(1) Number from Sales.Invoices s 
					where @PersonID = s.AccountsPersonID HAVING COUNT(1)>0) r1
	OUTER APPLY (Select N'Sales.Orders' TableName, count(1) Number from Sales.Orders s 
					where @PersonID = s.ContactPersonID AND r1.TableName is null HAVING COUNT(1)>0) r2
	OUTER APPLY (Select N'Sales.Customers' TableName, count(1) Number from Sales.Customers s 
					where @PersonID = s.PrimaryContactPersonID AND r1.TableName is null AND r2.TableName is null HAVING COUNT(1)>0) r3
	OUTER APPLY (Select N'Purchasing.Suppliers' TableName, count(1) Number from Purchasing.Suppliers s 
					where @PersonID = s.PrimaryContactPersonID AND r1.TableName is null AND r2.TableName is null AND r3.TableName is null HAVING COUNT(1)>0) r4
)
GO

-- grupowanie i licznik
declare @PersonId int = 3032
select * FROM dbo.GetPersonIdRefTable_Inline(@PersonId);
GO

-- takze grupowanie
declare @PersonId int = 3032
select TableName FROM dbo.GetPersonIdRefTable_Inline(@PersonId);
GO