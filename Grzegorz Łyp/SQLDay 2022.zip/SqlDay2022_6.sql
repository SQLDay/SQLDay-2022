-- czy poprawny paszport
CREATE OR ALTER FUNCTION dbo.IsValidPassport (@NrPaszportu char(9))
RETURNS INTEGER
AS
BEGIN
  --#2-->
  IF LEN(LTRIM(RTRIM(@NrPaszportu))) != 9 --#3
  BEGIN
    RETURN (0);
  END;

  IF ISNUMERIC(RIGHT( LEFT( @NrPaszportu, 1), 1)) = 1
  BEGIN
    RETURN (0);
  END;
  IF ISNUMERIC(RIGHT( LEFT( @NrPaszportu, 2), 1)) = 1
  BEGIN
    RETURN (0);
  END;
  IF ISNUMERIC(RIGHT( LEFT( @NrPaszportu, 3), 1)) = 0
  BEGIN
    RETURN (0);
  END;
  IF ISNUMERIC(RIGHT( LEFT( @NrPaszportu, 4), 1)) = 0
  BEGIN
    RETURN (0);
  END;
  IF ISNUMERIC(RIGHT( LEFT( @NrPaszportu, 5), 1)) = 0
  BEGIN
    RETURN (0);
  END;
  IF ISNUMERIC(RIGHT( LEFT( @NrPaszportu, 6), 1)) = 0
  BEGIN
    RETURN (0);
  END;
  IF ISNUMERIC(RIGHT( LEFT( @NrPaszportu, 7), 1)) = 0
  BEGIN
    RETURN (0);
  END;
  IF ISNUMERIC(RIGHT( LEFT( @NrPaszportu, 8), 1)) = 0
  BEGIN
    RETURN (0);
  END;
  IF ISNUMERIC(RIGHT( LEFT( @NrPaszportu, 9), 1)) = 0
  BEGIN
    RETURN (0);
  END;
  --#2--<

  DECLARE @S1 int, @S2 int, @S3 int, @S4 int, @S5 int, @S6 int, @S7 int, @S8 int, @S9 int, @CHECKSUM int;

  DECLARE @T TABLE
  (
    [Character] varchar(1) NULL ,
    [Number] int NULL
  );

  INSERT INTO @T ([Character], [Number])
  SELECT 'A', 10 UNION SELECT 'B', 11 UNION  SELECT 'C', 12 UNION SELECT 'D', 13 UNION  SELECT 'E', 14 UNION SELECT 'F', 15 UNION
  SELECT 'G', 16 UNION SELECT 'H', 17 UNION  SELECT 'I', 18 UNION SELECT 'J', 19 UNION  SELECT 'K', 20 UNION SELECT 'L', 21 UNION
  SELECT 'M', 22 UNION SELECT 'N', 23 UNION  SELECT 'O', 24 UNION SELECT 'P', 25 UNION  SELECT 'Q', 26 UNION SELECT 'R', 27 UNION
  SELECT 'S', 28 UNION SELECT 'T', 29 UNION  SELECT 'U', 30 UNION SELECT 'V', 31 UNION  SELECT 'W', 32 UNION SELECT 'X', 33 UNION
  SELECT 'Y', 34 UNION SELECT 'Z', 35;

  SET @S1 = (SELECT TOP 1  t.[Number] FROM @T t WHERE t.[Character] = LEFT( @NrPaszportu, 1)) * 7;
  SET @S2 = (SELECT TOP 1  t.[Number] FROM @T t WHERE t.[Character] = RIGHT( LEFT( @NrPaszportu, 2), 1)) * 3;
  SET @S3 = CONVERT(int, LEFT( RIGHT( @NrPaszportu, 7), 1)); --> 3 znak paszportu, kt�ry b�dzie por�wnywany z CheckSuma
  SET @S4 = CONVERT(int, RIGHT( LEFT( @NrPaszportu, 4), 1)) * 1;
  SET @S5 = CONVERT(int, RIGHT( LEFT( @NrPaszportu, 5), 1)) * 7;
  SET @S6 = CONVERT(int, RIGHT( LEFT( @NrPaszportu, 6), 1)) * 3;
  SET @S7 = CONVERT(int, RIGHT( LEFT( @NrPaszportu, 7), 1)) * 1;
  SET @S8 = CONVERT(int, RIGHT( LEFT( @NrPaszportu, 8), 1)) * 7;
  SET @S9 = CONVERT(int, RIGHT( LEFT( @NrPaszportu, 9), 1)) * 3;
  SET @CHECKSUM = (@S1 + @S2 + @S4 + @S5 + @S6 + @S7 + @S8 + @S9) % 10;

  IF ISNULL (LTRIM (@NrPaszportu), '') = ''
  BEGIN
    RETURN (0);
  END;

  IF LEN (@NrPaszportu) != 9
  BEGIN
    RETURN (0);
  END;

  IF @S1 IS NULL OR @S2 IS NULL
  BEGIN
    RETURN (0);
  END;

  IF @S3 = @CHECKSUM
  BEGIN
    RETURN (1);
  END;
  ELSE BEGIN
    RETURN (0);
  END;

  RETURN (1);
END;
GO

-- is_inlineable
select is_inlineable, * from sys.sql_modules where object_id = object_id('IsValidPassport')
GO

-- wersja inline ?