-- GETDATE
-- Przyk�adowe zapytanie
select * from application.People where GETDATE() between ValidFrom and ValidTo
GO

-- funkcja skalarna
create or alter function dbo.ExistValidPeople()
returns bit
as
begin
	return case when exists(select * from application.People where GETDATE() between ValidFrom and ValidTo)
				then 1
				else 0 end
end
GO

-- is_inlineable
select is_inlineable, * from sys.sql_modules where object_id = object_id('ExistValidPeople')
GO

-- wersja z paramertrem
create or alter function dbo.ExistValidPeople(@date datetime)
returns bit
as
begin
	return case when exists(select * from application.People where @date between ValidFrom and ValidTo)
				then 1
				else 0 end
end
GO

-- is_inlineable
select is_inlineable, * from sys.sql_modules where object_id = object_id('ExistValidPeople')
GO

-- wersja inline
create or alter function dbo.ExistValidPeople_inline()
returns table
as
return (select  case when exists(select * from application.People where GETDATE() between ValidFrom and ValidTo)
				then 1
				else 0 end Result)
GO

-- plan wykonania
select * from dbo.ExistValidPeople_inline()

-- na czym polega r�znica?