set statistics io off
GO
-- sprobojmy czegos innego
create or alter function dbo.GetPersonIdRefTable(@PersonID int)
returns sysname
as
begin
  declare @tableName sysname;

  Select TOP 1 @tableName = N'Sales.Invoices' from Sales.Invoices s where @PersonID = s.AccountsPersonID;
  
  IF @tableName IS NULL
	Select TOP 1 @tableName = N'Sales.Orders' from Sales.Orders s where @PersonID = s.ContactPersonID
  
  IF @tableName IS NULL
    Select TOP 1 @tableName = N'Sales.Customers' from Sales.Customers s where @PersonID = s.PrimaryContactPersonID

  IF @tableName IS NULL
    Select TOP 1 @tableName =N'Purchasing.Suppliers' from Purchasing.Suppliers s where @PersonID = s.PrimaryContactPersonID

  return @tableName;
end
GO
-- czy moze by zinlinowiona?
select is_inlineable, * from sys.sql_modules where object_id = object_id('GetPersonIdRefTable')
GO
-- ile reads
set statistics io on
GO
declare @PersonId int = 3032
select dbo.GetPersonIdRefTable(@PersonId);
GO

-- inna wersja
create or alter function dbo.GetPersonIdRefTable_2(@PersonID int)
returns sysname
as
begin
  declare @tableName sysname;
	
  IF EXISTS(Select 1 from Sales.Invoices s where @PersonID = s.AccountsPersonID)
	set @tableName = N'Sales.Invoices';
  ELSE
  IF EXISTS(Select 1 from Sales.Orders s where @PersonID = s.ContactPersonID)
	set @tableName = N'Sales.Orders';
  ELSE
  IF EXISTS(Select 1 from Sales.Customers s where @PersonID = s.PrimaryContactPersonID)
	set @tableName = N'Sales.Customers';
  ELSE
  IF EXISTS(Select 1 from Purchasing.Suppliers s where @PersonID = s.PrimaryContactPersonID)
	set @tableName = N'Purchasing.Suppliers';

  return @tableName;
end
GO
select is_inlineable, * from sys.sql_modules where object_id = object_id('GetPersonIdRefTable_2')
GO

-- ile reads
set statistics io on
GO
declare @PersonId int = 3032
select dbo.GetPersonIdRefTable_2(@PersonId);
GO

-- sprobujmy to napisac w postaci funkcji inline





















-- przyklad rozwiazania
create or alter function dbo.GetPersonIdRefTable_Inline(@PersonID int)
returns table
as
return(
	SELECT COALESCE(r1.TableName, r2.TableName, r3.TableName, r4.TableName) TableName
	FROM (select 1 a) x
	OUTER APPLY (Select TOP 1 N'Sales.Invoices' TableName from Sales.Invoices s where @PersonID = s.AccountsPersonID) r1
	OUTER APPLY (Select TOP 1 N'Sales.Orders' TableName from Sales.Orders s where @PersonID = s.ContactPersonID) r2
	OUTER APPLY (Select TOP 1 N'Sales.Customers' TableName from Sales.Customers s where @PersonID = s.PrimaryContactPersonID) r3
	OUTER APPLY (Select TOP 1 N'Purchasing.Suppliers' TableName from Purchasing.Suppliers s where @PersonID = s.PrimaryContactPersonID) r4
)
GO
-- ile reads
set statistics io on
GO
declare @PersonId int = 3032
select dbo.GetPersonIdRefTable(@PersonId);
GO
declare @PersonId int = 3032
select * FROM dbo.GetPersonIdRefTable_Inline(@PersonId);
GO
-- poprawmy funkcje inline - startup predicate
create or alter function dbo.GetPersonIdRefTable_Inline(@PersonID int)
returns table
as
return(
	SELECT COALESCE(r1.TableName, r2.TableName, r3.TableName, r4.TableName) TableName
	FROM (select 1 a) x
	OUTER APPLY (Select TOP 1 N'Sales.Invoices' TableName from Sales.Invoices s 
					where @PersonID = s.AccountsPersonID) r1
	OUTER APPLY (Select TOP 1 N'Sales.Orders' TableName from Sales.Orders s 
					where @PersonID = s.ContactPersonID AND r1.TableName is null) r2
	OUTER APPLY (Select TOP 1 N'Sales.Customers' TableName from Sales.Customers s 
					where @PersonID = s.PrimaryContactPersonID AND r2.TableName is null) r3
	OUTER APPLY (Select TOP 1 N'Purchasing.Suppliers' TableName from Purchasing.Suppliers s 
					where @PersonID = s.PrimaryContactPersonID AND r3.TableName is null) r4
)
GO
-- ile reads
declare @PersonId int = 3032
select dbo.GetPersonIdRefTable(@PersonId);
GO
declare @PersonId int = 3032
select * FROM dbo.GetPersonIdRefTable_Inline(@PersonId);
GO

-- jeszcze jedna zmiana
create or alter function dbo.GetPersonIdRefTable_Inline(@PersonID int)
returns table
as
return(
	SELECT COALESCE(r1.TableName, r2.TableName, r3.TableName, r4.TableName) TableName
	FROM (select 1 a) x
	OUTER APPLY (Select TOP 1 N'Sales.Invoices' TableName from Sales.Invoices s 
					where @PersonID = s.AccountsPersonID) r1
	OUTER APPLY (Select TOP 1 N'Sales.Orders' TableName from Sales.Orders s 
					where @PersonID = s.ContactPersonID AND r1.TableName is null) r2
	OUTER APPLY (Select TOP 1 N'Sales.Customers' TableName from Sales.Customers s 
					where @PersonID = s.PrimaryContactPersonID AND r1.TableName is null AND r2.TableName is null) r3
	OUTER APPLY (Select TOP 1 N'Purchasing.Suppliers' TableName from Purchasing.Suppliers s 
					where @PersonID = s.PrimaryContactPersonID AND r1.TableName is null AND r2.TableName is null AND r3.TableName is null) r4
)
GO

-- ile reads
declare @PersonId int = 3032
select dbo.GetPersonIdRefTable(@PersonId);
GO
declare @PersonId int = 3032
select * FROM dbo.GetPersonIdRefTable_Inline(@PersonId);
GO

-- jak dzia�a Startup Predicate
declare @x int
declare @PersonId int = 3032
select * from Application.People where PersonID = @PersonId and @x = 0
GO
