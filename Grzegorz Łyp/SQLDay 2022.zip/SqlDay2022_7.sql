-- dodatkowy przypadek
create or alter function dbo.CheckSomething(@Par1 bit, @Par2 bit, @PersonId int)
returns bit
as
begin
  declare @result bit = 0;

  if @Par1 = 1 and @Par2 = 0 set @Par2 = CASE WHEN DATEPART(day,GETDATE()) = 1 THEN 1 ELSE 0 END

  declare @IsOk bit, @IsNotOk bit, @ExistsInvoice bit = 0, @ExistsOrder bit = 0

  IF EXISTS(SELECT 1 FROM Sales.Invoices where ContactPersonID = @PersonId)
	SET @ExistsInvoice = 1

  IF EXISTS(SELECT 1 FROM Sales.Orders where ContactPersonID = @PersonId)
	SET @ExistsOrder = 1

  if @Par1 = 1 and @ExistsInvoice = 0
	SET @IsOk = 1

  if @Par1 = 0
  begin
	if @ExistsInvoice = 0 SET @IsOk = 0
	ELSE
		Set @IsNotOk = 1
  end

  if @Par2 = 1 and @ExistsOrder = 1
  begin
	if @ExistsInvoice = 1 AND @Par1 = 1 Set @IsNotOk = 1
	else
		SET @IsNotOk = 0;
  end

  if @IsNotOk = 1 
  begin
	if @Par1 = 1 and @Par2 = 0 SET @result = 1
	if @ExistsInvoice = 1 and @Par2 = 0 SET @Result = 0
  end

  if @IsOk = 0
  begin
	if @ExistsOrder = 1 SET @result = 0
	if @Par2 = 0 and @ExistsOrder = 0 Set @result = 1
  end

  return @result;
end
GO

-- is_inlineable
select is_inlineable, * from sys.sql_modules where object_id = object_id('CheckSomething')
GO