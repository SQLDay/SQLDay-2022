-- dodatkowy przypadek
create or alter function dbo.CheckSomething_inline(@Par1 bit, @Par2 bit, @PersonId int)
returns table
as
return (
	with dane as (
		select @Par1 Par1,
			   CASE WHEN @Par1 = 1 and @Par2 = 0 
					THEN CASE WHEN DATEPART(day,GETDATE()) = 1 THEN 1 ELSE 0 END 
					ELSE @Par2 END Par2,
			   CASE WHEN EXISTS(SELECT 1 FROM Sales.Invoices where ContactPersonID = @PersonId)
					THEN 1 
					ELSE 0 END ExistsInvoice,
			   CASE WHEN EXISTS(SELECT 1 FROM Sales.Orders where ContactPersonID = @PersonId)
				    THEN 1
					ELSE 0 END ExistsOrder
	),
	dane2 as (
		select d.*,
		       CASE WHEN d.Par1 = 1 AND d.ExistsInvoice = 0 THEN 1
					WHEN d.Par1 = 0 AND d.ExistsInvoice = 0 THEN 0
					ELSE 0 END IsOk,
			   CASE WHEN d.Par1 = 0 AND d.ExistsInvoice = 1 THEN 1
			        WHEN d.Par2 = 1 AND d.ExistsOrder = 1 THEN
						CASE WHEN d.ExistsInvoice = 1 AND d.Par1 = 1 THEN 1 ELSE 0 END
				    ELSE 0 END IsNotOk

			from dane d
	)
	SELECT
		CASE WHEN d.IsNotOk = 1 AND d.Par1 = 1 and d.Par2 = 0 THEN 1
		     WHEN d.IsNotOk = 1 AND d.ExistsInvoice = 1 AND d.Par2 = 0 THEN 0
			 WHEN d.IsOk = 0 AND d.ExistsOrder = 1 THEN 0
			 WHEN d.IsOk = 0 AND d.Par2 = 0 AND d.ExistsOrder = 0 THEN 1
			 ELSE 0 END Result

	  FROM dane2 d
)

-- jak wygl�da plan
declare @Par1 bit, @Par2 bit, @PersonId int
select * from dbo.CheckSomething_inline(@Par1, @Par2, @PersonId)
GO