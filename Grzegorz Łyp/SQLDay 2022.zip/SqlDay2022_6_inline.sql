-- czy poprawny paszport
CREATE OR ALTER FUNCTION dbo.IsValidPassport_inline (@NrPaszportu char(9))
RETURNS TABLE
AS
RETURN (
	WITH dane AS (
	  SELECT 'A' [Character], 10 [Number] UNION SELECT 'B', 11 UNION  SELECT 'C', 12 UNION SELECT 'D', 13 UNION  SELECT 'E', 14 UNION SELECT 'F', 15 UNION
	  SELECT 'G', 16 UNION SELECT 'H', 17 UNION  SELECT 'I', 18 UNION SELECT 'J', 19 UNION  SELECT 'K', 20 UNION SELECT 'L', 21 UNION
	  SELECT 'M', 22 UNION SELECT 'N', 23 UNION  SELECT 'O', 24 UNION SELECT 'P', 25 UNION  SELECT 'Q', 26 UNION SELECT 'R', 27 UNION
	  SELECT 'S', 28 UNION SELECT 'T', 29 UNION  SELECT 'U', 30 UNION SELECT 'V', 31 UNION  SELECT 'W', 32 UNION SELECT 'X', 33 UNION
	  SELECT 'Y', 34 UNION SELECT 'Z', 35
	),
	dane2 AS (
		SELECT S1 = (SELECT TOP 1  t.[Number] FROM dane t WHERE t.[Character] = LEFT( @NrPaszportu, 1)) * 7,
			   S2 = (SELECT TOP 1  t.[Number] FROM dane t WHERE t.[Character] = RIGHT( LEFT( @NrPaszportu, 2), 1)) * 3,
			   S3 = CONVERT(int, LEFT( RIGHT( @NrPaszportu, 7), 1)),
			   S4 = CONVERT(int, RIGHT( LEFT( @NrPaszportu, 4), 1)) * 1,
		       S5 = CONVERT(int, RIGHT( LEFT( @NrPaszportu, 5), 1)) * 7,
		       S6 = CONVERT(int, RIGHT( LEFT( @NrPaszportu, 6), 1)) * 3,
		       S7 = CONVERT(int, RIGHT( LEFT( @NrPaszportu, 7), 1)) * 1,
		       S8 = CONVERT(int, RIGHT( LEFT( @NrPaszportu, 8), 1)) * 7,
		       S9 = CONVERT(int, RIGHT( LEFT( @NrPaszportu, 9), 1)) * 3
	)

	SELECT
		CASE WHEN LEN(LTRIM(RTRIM(@NrPaszportu))) != 9 THEN 0
			 WHEN ISNUMERIC(SUBSTRING( @NrPaszportu, 1, 1)) = 1 THEN 0
			 WHEN ISNUMERIC(SUBSTRING( @NrPaszportu, 2, 1)) = 1 THEN 0
			 WHEN ISNUMERIC(SUBSTRING( @NrPaszportu, 3, 1)) = 0 THEN 0
			 WHEN ISNUMERIC(SUBSTRING( @NrPaszportu, 4, 1)) = 0 THEN 0
			 WHEN ISNUMERIC(SUBSTRING( @NrPaszportu, 5, 1)) = 0 THEN 0
			 WHEN ISNUMERIC(SUBSTRING( @NrPaszportu, 6, 1)) = 0 THEN 0
			 WHEN ISNUMERIC(SUBSTRING( @NrPaszportu, 7, 1)) = 0 THEN 0
			 WHEN ISNUMERIC(SUBSTRING( @NrPaszportu, 8, 1)) = 0 THEN 0
			 WHEN ISNUMERIC(SUBSTRING( @NrPaszportu, 9, 1)) = 0 THEN 0
			 WHEN ISNULL (LTRIM (@NrPaszportu), '') = '' THEN 0
			 WHEN LEN (@NrPaszportu) != 9 THEN 0
			 WHEN d.S1 IS NULL OR d.S2 IS NULL THEN 0
			 WHEN (d.S1 + d.S2 + d.S4 + d.S5 + d.S6 + d.S7 + d.S8 + d.S9) % 10 <> d.S3 THEN 0
			 ELSE 1 END Result
		FROM dane2 d

)
GO
-- jak wygl�da plan
declare @NrPaszportu char(9)
select * from dbo.IsValidPassport_inline(@NrPaszportu)
GO
