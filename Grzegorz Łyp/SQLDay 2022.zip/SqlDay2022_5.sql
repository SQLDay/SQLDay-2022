-- przyk�ad funkcji
CREATE OR ALTER FUNCTION dbo.trimspecial(@s varchar(255))
RETURNS varchar(255)
WITH SCHEMABINDING
BEGIN
 WHILE @s LIKE '%  %' SET @s=REPLACE(@s,'  ',' ');
 SET @s=RTRIM(LTRIM(@s));
 RETURN @s;
END;
GO

-- is_inlineable
select is_inlineable, * from sys.sql_modules where object_id = object_id('trimspecial')
GO
-- IsSchemaBound
select OBJECTPROPERTY(object_id('trimspecial'), 'IsSchemaBound')
GO

-- wersja bez SCHEMABINDING
CREATE OR ALTER  FUNCTION dbo.trimspecial(@s varchar(255))
RETURNS varchar(255)
BEGIN
 WHILE @s LIKE '%  %' SET @s=REPLACE(@s,'  ',' ');
 SET @s=RTRIM(LTRIM(@s));
 RETURN @s;
END;
GO

-- is_inlineable
select is_inlineable, * from sys.sql_modules where object_id = object_id('trimspecial')
GO

-- przebudowa funkcji
CREATE OR ALTER  FUNCTION dbo.trimspecial(@s varchar(255))
RETURNS varchar(255)
BEGIN
  SELECT @S = TRIM(STRING_AGG(VALUE,' ')) FROM STRING_SPLIT(@S,' ')
	WHERE VALUE<>' ';
 RETURN @s;
END;
GO

-- is_inlineable
select is_inlineable, * from sys.sql_modules where object_id = object_id('trimspecial')
GO

-- wersja inline
CREATE OR ALTER  FUNCTION dbo.trimspecial_inline(@s varchar(255))
RETURNS TABLE
AS
RETURN(
  SELECT TRIM(STRING_AGG(VALUE,' ')) Result
	FROM STRING_SPLIT(@S,' ') 
	WHERE VALUE<>' '
)
GO

-- przywracamy oryginaln� funkcj� do testu
CREATE OR ALTER FUNCTION dbo.trimspecial(@s varchar(255))
RETURNS varchar(255)
WITH SCHEMABINDING
BEGIN
 WHILE @s LIKE '%  %' SET @s=REPLACE(@s,'  ',' ');
 SET @s=RTRIM(LTRIM(@s));
 RETURN @s;
END;
GO

-- test dzia�ania
select Result from dbo.trimspecial_inline(' SQL  DAY   2022  IS    COOL  ')
select dbo.trimspecial(' SQL  DAY   2022  IS    COOL  ')