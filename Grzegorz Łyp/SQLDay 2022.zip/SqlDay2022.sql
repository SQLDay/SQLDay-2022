-- Compatiblity Level 150
-- set statistics io off
-- uruchamiamy profiler na batche
-- ZoomIt64 - Ctrl+Alt+Z

-- kolumny o najwiekszej ilosci odwolan
select top 10 referenced_Column_id, referenced_object_id, count(1)
from sys.foreign_key_columns 
group by referenced_Column_id, referenced_object_id
order by 3 desc
GO
select schema_name(schema_id),* from sys.objects where object_id = 1301579675
GO
select * from Application.People
GO
-- Do czego sie odwolujemy?
select top 10 object_name(parent_object_id), *
from sys.foreign_key_columns 
where referenced_object_id = 1301579675 and referenced_Column_id = 1
order by parent_object_id desc, parent_column_id
GO
select schema_name(schema_id),* from sys.objects where object_id = 2018106230
GO
-- jedna tabela wiele odwolan
select * from sys.columns where object_id = object_id('Sales.Invoices') and column_id in (6,7,8,9)
GO
select * from Sales.Invoices
GO
-- proba usuniecia
DELETE FROM Application.People WHERE PersonID = 3032
GO
-- zrobmy funkcje ktora nam to sprawdzi
create or alter function dbo.IsPersonIdRef(@PersonID int)
returns bit
as
begin
  declare @retValue bit = 0;

  if exists(Select 1 from Sales.Invoices s where @PersonID in (s.AccountsPersonID, s.ContactPersonID, s.PackedByPersonID, s.SalespersonPersonID))
	set @retValue = 1;

  return @retValue;
end
GO
-- plan wykonania pokazuje skan, SQL wykonuje OR pomiedzy opcjami
-- przebudowa funkcji
create or alter function dbo.IsPersonIdRef(@PersonID int)
returns bit
as
begin
  if exists(Select 1 from Sales.Invoices s where @PersonID = s.AccountsPersonID)
	return 1;

  if exists(Select 1 from Sales.Invoices s where @PersonID = s.ContactPersonID)
	return 1;

  if exists(Select 1 from Sales.Invoices s where @PersonID = s.PackedByPersonID)
	return 1;

  if exists(Select 1 from Sales.Invoices s where @PersonID = s.SalespersonPersonID)
	return 1;

  return 0;
end
GO
-- plan wykonania pokazuje SEEK, sukces
-- czy moze by zinlinowiona?
select is_inlineable, * from sys.sql_modules where object_id = object_id('IsPersonIdRef')
GO
-- moze uda nam sie to naprawic
create or alter function dbo.IsPersonIdRef(@PersonID int)
returns bit
as
begin
  if exists(Select 1 from Sales.Invoices s where @PersonID = s.AccountsPersonID)
	return 1;
  else
  if exists(Select 1 from Sales.Invoices s where @PersonID = s.ContactPersonID)
	return 1;
  else
  if exists(Select 1 from Sales.Invoices s where @PersonID = s.PackedByPersonID)
	return 1;
  else
  if exists(Select 1 from Sales.Invoices s where @PersonID = s.SalespersonPersonID)
	return 1;
  else
	return 0;
  
  return 0;
end
GO
-- czy moze by zinlinowiona?
select is_inlineable, * from sys.sql_modules where object_id = object_id('IsPersonIdRef')
GO
-- jeszcze jedna proba
create or alter function dbo.IsPersonIdRef(@PersonID int)
returns bit
as
begin 
  declare @retValue bit = 0;
  if exists(Select 1 from Sales.Invoices s where @PersonID = s.AccountsPersonID)
	set @retValue = 1;
  else
  if exists(Select 1 from Sales.Invoices s where @PersonID = s.ContactPersonID)
	set @retValue = 1;
  else
  if exists(Select 1 from Sales.Invoices s where @PersonID = s.PackedByPersonID)
	set @retValue = 1;
  else
  if exists(Select 1 from Sales.Invoices s where @PersonID = s.SalespersonPersonID)
	set @retValue = 1;
  
  return @retValue;
end
GO
-- czy moze by zinlinowiona?
select is_inlineable, * from sys.sql_modules where object_id = object_id('IsPersonIdRef')
GO
-- propozycje jak napisac to jako funkcja inline





















-- moze jednak warto miec stabilne rozwiazanie
-- funkcja inline
create or alter function dbo.IsPersonIdRef_Inline(@PersonID int)
returns table
as
return (
	select case when exists(Select 1 from Sales.Invoices s where @PersonID = s.AccountsPersonID) then 1
			    when exists(Select 1 from Sales.Invoices s where @PersonID = s.ContactPersonID) then 1
				when exists(Select 1 from Sales.Invoices s where @PersonID = s.PackedByPersonID) then 1
				when exists(Select 1 from Sales.Invoices s where @PersonID = s.SalespersonPersonID) then 1
				else 0 END Result
)
go

-- czy funkcja skalarna zostala na pewno zinlinowiona? jaki jest plan wykonania?
declare @PersonId int
select dbo.IsPersonIdRef(@PersonId);
GO
-- a jaki jest plan wykonania funkcji inline?
declare @PersonId int
select * from dbo.IsPersonIdRef_Inline(@PersonId);

-- sprawdzmy ilosc odczytow
set statistics io on
GO
-- wersja UDF
declare @PersonId int = 3032
select dbo.IsPersonIdRef(@PersonId);
GO
-- wersja inline
declare @PersonId int = 3032
select * from dbo.IsPersonIdRef_Inline(@PersonId);
GO
-- sporo reads na wersji UDF - zrobmy wersje nie inlinowjaca sie
create or alter function dbo.IsPersonIdRef_bad(@PersonID int)
returns bit
as
begin
  if exists(Select 1 from Sales.Invoices s where @PersonID = s.AccountsPersonID)
	return 1;

  if exists(Select 1 from Sales.Invoices s where @PersonID = s.ContactPersonID)
	return 1;

  if exists(Select 1 from Sales.Invoices s where @PersonID = s.PackedByPersonID)
	return 1;

  if exists(Select 1 from Sales.Invoices s where @PersonID = s.SalespersonPersonID)
	return 1;

  return 0;
end
GO
-- wersja UDF - zla
declare @PersonId int = 3032
select dbo.IsPersonIdRef_bad(@PersonId);
GO
-- uzyjmy profilera

-- wersja UDF - zla
declare @PersonId int = 3032
select dbo.IsPersonIdRef_bad(@PersonId);
GO
-- wersja UDF
declare @PersonId int = 3032
select dbo.IsPersonIdRef(@PersonId);
GO
-- wersja inline
declare @PersonId int = 3032
select * from dbo.IsPersonIdRef_Inline(@PersonId);
GO



-- EXTRA BONUS - inna wersja inline
create or alter function dbo.IsPersonIdRef_Inline_2(@PersonID int)
returns table
as
return (
	select case when exists(Select 1 from Sales.Invoices s where @PersonID = s.AccountsPersonID) OR
			         exists(Select 1 from Sales.Invoices s where @PersonID = s.ContactPersonID) OR
				     exists(Select 1 from Sales.Invoices s where @PersonID = s.PackedByPersonID) OR
				     exists(Select 1 from Sales.Invoices s where @PersonID = s.SalespersonPersonID) then 1
				else 0 END Result
)
go
declare @PersonId int = 3032
select * from dbo.IsPersonIdRef_Inline_2(@PersonId);
GO
declare @PersonId int = 3032
select * from dbo.IsPersonIdRef_Inline(@PersonId);
GO

-- por�wnanie wydajno�ci scalar vs inline
-- statystyki na time
set statistics time on
go
select dbo.IsPersonIdRef_bad(p.PersonID) from Application.People p -- Scalar
GO
select dbo.IsPersonIdRef(p.PersonID) from Application.People p -- Inlinable
GO
select x.Result from Application.People p -- Inline
cross apply dbo.IsPersonIdRef_Inline(p.PersonID) x;
GO
set statistics time off

-- Cross apply - czy warto - funkcja z jednym rekordem?
-- plan wykonania
select p.* from Application.People p -- Inline
cross apply dbo.IsPersonIdRef_Inline(p.PersonID) x;
GO